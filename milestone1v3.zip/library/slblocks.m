function blkStruct = slblocks
	Browser.Library = 'tinbot';
	Browser.Name = 'Tin Bot Library';
    Browser.IsFlat  = 1;
	blkStruct.Browser = Browser;