function blkStruct = slblocks
	Browser.Library = 'tinbot';
	Browser.Name = 'Tin Bot Library 2';
    Browser.IsFlat  = 1;
	blkStruct.Browser = Browser;